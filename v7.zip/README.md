# wax-farm-bot
CODE BASE: https://github.com/worldwide-asset-exchange/waxjs
> donate :beer:: 13.gm
> 
For farmersworld/farmingtales/nftpanda/officeland

<hr>
<h1>CHANGELOG</h1>
<h3>=>&nbsp;220128</h3>
<h5>&emsp;- Auto build farm plot</h5>
<h5>&emsp;- Auto stake barley/corn</h5>
<h3>=>&nbsp;220120</h3>
<h5>&emsp;- Show CPU usage</h5>
<h5>&emsp;- Update UI</h5>
<br><hr>

1. Download zip and Extract/Unzip to wherever you want
2. Install npm and nodejs
> https://docs.npmjs.com/downloading-and-installing-node-js-and-npm
3. Input your line token to .env file
> TOKEN=uaIASUeuqieuiHAIHFHDAIFNKjdankfJ
4. run
<img src="https://user-images.githubusercontent.com/49296797/149676211-a0e27305-7fbc-498e-8f77-795f7ad2280e.png" width=70%>

```
node .
```
5. open browser and go to
> http://localhost:6969/

<br>
- You should check automatically for login and mining transaction, or you need to click approve every hour <br>
<img src="https://user-images.githubusercontent.com/49296797/141811955-44838d94-46ce-436c-ba8a-eb87d77cf98a.png" width=70%>

- uncheck if you don't want to mine <br>
<img src="https://user-images.githubusercontent.com/49296797/149676054-bf88ecac-d82a-4217-bd47-9e9649a02ea0.png" width=70%>

- line notification <br>
> https://notify-bot.line.me/en/
<img src="https://user-images.githubusercontent.com/49296797/141815250-6f1aba09-97f6-4024-90f0-bfa75d1a57ad.png" width=40%>
<br><hr>
<h1>SIDE PROJECT FOR SIMULATE PORT</h1>
https://farmersworld-simulator.vercel.app/
<img src="https://user-images.githubusercontent.com/49296797/151424770-f9ee8dd7-96a8-49cc-b1db-22f84f1143bd.png" width=40%>
